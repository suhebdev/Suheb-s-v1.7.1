import {
  RecaptchaVerifier,
  signInWithPhoneNumber,
  signOut,
  onAuthStateChanged,
} from "firebase/auth";
import { auth } from "./config";

let recaptchaVerifier = null;

/**
 * Creates (or reuses) an invisible reCAPTCHA verifier attached to the
 * given container element id. Must exist before calling sendOtp().
 *
 * Note: signature is (auth, container, params) for Firebase JS SDK v10+.
 * If you're on an older v9.x release, swap to (container, params, auth).
 */
export function getRecaptchaVerifier(containerId = "recaptcha-container") {
  if (!recaptchaVerifier) {
    recaptchaVerifier = new RecaptchaVerifier(auth, containerId, {
      size: "invisible",
    });
  }
  return recaptchaVerifier;
}

/** Clears the current verifier so a fresh one is built on next send. */
export function resetRecaptcha() {
  if (recaptchaVerifier) {
    recaptchaVerifier.clear();
    recaptchaVerifier = null;
  }
}

/**
 * Sends an OTP to a phone number in E.164 format (e.g. +14155552671).
 * Returns a confirmationResult — keep it and pass it to confirmOtp().
 */
export async function sendOtp(phoneNumber) {
  const verifier = getRecaptchaVerifier();
  return signInWithPhoneNumber(auth, phoneNumber, verifier);
}

/** Confirms the 6-digit code against the confirmationResult from sendOtp(). */
export async function confirmOtp(confirmationResult, code) {
  return confirmationResult.confirm(code);
}

export function logout() {
  resetRecaptcha();
  return signOut(auth);
}

/** Subscribes to auth state changes. Returns an unsubscribe function. */
export function subscribeToAuthChanges(callback) {
  return onAuthStateChanged(auth, callback);
}

/** Maps Firebase auth error codes to plain, actionable messages. */
export function getAuthErrorMessage(error) {
  const code = error?.code || "";
  switch (code) {
    case "auth/invalid-phone-number":
      return "That phone number doesn't look right. Include the country code, e.g. +1 415 555 2671.";
    case "auth/missing-phone-number":
      return "Enter a phone number first.";
    case "auth/too-many-requests":
      return "Too many attempts from this device. Wait a while before trying again.";
    case "auth/quota-exceeded":
      return "SMS limit reached for this project. Try again later.";
    case "auth/captcha-check-failed":
      return "Verification check failed. Refresh the page and try again.";
    case "auth/invalid-verification-code":
      return "That code is incorrect. Check it and try again.";
    case "auth/code-expired":
      return "This code expired. Send a new one.";
    case "auth/network-request-failed":
      return "Connection issue. Check your network and try again.";
    case "auth/user-disabled":
      return "This account has been disabled.";
    default:
      return error?.message || "Something went wrong. Please try again.";
  }
}
