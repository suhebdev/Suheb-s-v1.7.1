import { useEffect, useRef, useState } from "react";
import {
  sendOtp,
  confirmOtp,
  resetRecaptcha,
  getAuthErrorMessage,
} from "../firebase/auth";

const PHONE_REGEX = /^\+[1-9]\d{7,14}$/;
const OTP_LENGTH = 6;
const RESEND_SECONDS = 30;

export default function AuthPage() {
  const [step, setStep] = useState("phone"); // "phone" | "otp"
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState(Array(OTP_LENGTH).fill(""));
  const [confirmationResult, setConfirmationResult] = useState(null);
  const [status, setStatus] = useState("idle"); // idle | sending | verifying
  const [error, setError] = useState("");
  const [cooldown, setCooldown] = useState(0);
  const otpRefs = useRef([]);
  const busy = status !== "idle";

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [cooldown]);

  async function handleSendOtp(e) {
    e.preventDefault();
    setError("");

    const trimmed = phone.trim();
    if (!PHONE_REGEX.test(trimmed)) {
      setError("Enter a valid number with country code, e.g. +1 415 555 2671.");
      return;
    }

    setStatus("sending");
    try {
      const result = await sendOtp(trimmed);
      setConfirmationResult(result);
      setStep("otp");
      setOtp(Array(OTP_LENGTH).fill(""));
      setCooldown(RESEND_SECONDS);
      setTimeout(() => otpRefs.current[0]?.focus(), 50);
    } catch (err) {
      resetRecaptcha();
      setError(getAuthErrorMessage(err));
    } finally {
      setStatus("idle");
    }
  }

  async function handleResend() {
    if (cooldown > 0 || busy) return;
    setError("");
    setStatus("sending");
    try {
      const result = await sendOtp(phone.trim());
      setConfirmationResult(result);
      setOtp(Array(OTP_LENGTH).fill(""));
      setCooldown(RESEND_SECONDS);
      otpRefs.current[0]?.focus();
    } catch (err) {
      resetRecaptcha();
      setError(getAuthErrorMessage(err));
    } finally {
      setStatus("idle");
    }
  }

  async function handleVerify(codeOverride) {
    const code = (codeOverride ?? otp.join("")).trim();
    if (code.length !== OTP_LENGTH) {
      setError(`Enter the ${OTP_LENGTH}-digit code.`);
      return;
    }
    if (!confirmationResult) {
      setError("Session expired. Send a new code.");
      setStep("phone");
      return;
    }

    setError("");
    setStatus("verifying");
    try {
      await confirmOtp(confirmationResult, code);
      // onAuthStateChanged in App.jsx picks up the signed-in user and
      // swaps in HomePage automatically — nothing else to do here.
    } catch (err) {
      setError(getAuthErrorMessage(err));
      setOtp(Array(OTP_LENGTH).fill(""));
      otpRefs.current[0]?.focus();
    } finally {
      setStatus("idle");
    }
  }

  function handleOtpChange(index, value) {
    const digit = value.replace(/\D/g, "").slice(-1);
    const next = [...otp];
    next[index] = digit;
    setOtp(next);

    if (digit && index < OTP_LENGTH - 1) {
      otpRefs.current[index + 1]?.focus();
    }
    if (next.every((d) => d)) {
      handleVerify(next.join(""));
    }
  }

  function handleOtpKeyDown(index, e) {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  }

  function handleOtpPaste(e) {
    const text = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, OTP_LENGTH);
    if (!text) return;
    e.preventDefault();

    const next = Array(OTP_LENGTH).fill("");
    text.split("").forEach((d, i) => (next[i] = d));
    setOtp(next);

    const lastIndex = Math.min(text.length, OTP_LENGTH) - 1;
    otpRefs.current[lastIndex]?.focus();
    if (text.length === OTP_LENGTH) handleVerify(text);
  }

  function handleChangeNumber() {
    setStep("phone");
    setOtp(Array(OTP_LENGTH).fill(""));
    setError("");
    setConfirmationResult(null);
    resetRecaptcha();
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className={`signal${busy ? " signal-active" : ""}`}>
          <span className="signal-ring r1" />
          <span className="signal-ring r2" />
          <span className="signal-ring r3" />
          <svg className="signal-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.01-.24c1.12.37 2.33.57 3.58.57a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C10.61 21 3 13.39 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.46.57 3.58a1 1 0 0 1-.25 1.01l-2.2 2.2Z"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinejoin="round"
            />
          </svg>
        </div>

        {step === "phone" ? (
          <>
            <h1 className="auth-title">Verify it's you</h1>
            <p className="auth-subtitle">
              Enter your phone number and we'll send a one-time code to confirm it's really you.
            </p>

            <form onSubmit={handleSendOtp} className="auth-form">
              <label className="field-label" htmlFor="phone">Phone number</label>
              <input
                id="phone"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                placeholder="+1 415 555 2671"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="phone-input"
                disabled={busy}
              />
              <p className="field-hint">Include your country code, starting with +.</p>

              {error && <p className="error-text" role="alert">{error}</p>}

              <button type="submit" className="primary-btn" disabled={busy}>
                {status === "sending" ? <span className="btn-spinner" /> : "Send code"}
              </button>
            </form>
          </>
        ) : (
          <>
            <h1 className="auth-title">Enter the code</h1>
            <p className="auth-subtitle">
              We sent a {OTP_LENGTH}-digit code to <span className="phone-chip">{phone.trim()}</span>.
            </p>

            <div className="otp-row" onPaste={handleOtpPaste}>
              {otp.map((digit, i) => (
                <input
                  key={i}
                  ref={(el) => (otpRefs.current[i] = el)}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(i, e.target.value)}
                  onKeyDown={(e) => handleOtpKeyDown(i, e)}
                  className="otp-box"
                  disabled={busy}
                  autoFocus={i === 0}
                />
              ))}
            </div>

            {error && <p className="error-text" role="alert">{error}</p>}

            <button type="button" className="primary-btn" onClick={() => handleVerify()} disabled={busy}>
              {status === "verifying" ? <span className="btn-spinner" /> : "Verify & continue"}
            </button>

            <div className="auth-links">
              <button type="button" className="link-btn" onClick={handleChangeNumber} disabled={busy}>
                Change number
              </button>
              <button
                type="button"
                className="link-btn"
                onClick={handleResend}
                disabled={busy || cooldown > 0}
              >
                {cooldown > 0 ? `Resend in ${cooldown}s` : "Resend code"}
              </button>
            </div>
          </>
        )}
      </div>

      {/* Required mount point for Firebase's invisible reCAPTCHA */}
      <div id="recaptcha-container" />

      <Styles />
    </div>
  );
}

function Styles() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700&family=Inter:wght@400;500;600&display=swap');

      .auth-page {
        --bg: #0A0D12;
        --card: #13161D;
        --border: rgba(255,255,255,0.08);
        --text: #EDEFF3;
        --text-dim: #8A90A0;
        --accent: #F2A93B;
        --accent-dim: rgba(242,169,59,0.16);
        --teal: #1F6F6B;
        --danger: #FF6B6B;

        min-height: 100vh;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: radial-gradient(circle at 50% -10%, #161B24 0%, var(--bg) 55%);
        font-family: 'Inter', system-ui, sans-serif;
        color: var(--text);
        padding: 24px;
        box-sizing: border-box;
      }

      .auth-card {
        width: 100%;
        max-width: 380px;
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: 20px;
        padding: 36px 32px 32px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.45);
        display: flex;
        flex-direction: column;
      }

      .signal {
        position: relative;
        width: 64px;
        height: 64px;
        margin: 0 auto 20px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .signal::before {
        content: "";
        position: absolute;
        inset: 8px;
        border-radius: 50%;
        background: var(--accent-dim);
      }
      .signal-icon {
        position: relative;
        z-index: 2;
        width: 26px;
        height: 26px;
        color: var(--accent);
      }
      .signal-ring {
        position: absolute;
        inset: 0;
        border-radius: 50%;
        border: 1.5px solid var(--teal);
        opacity: 0;
        animation: signal-pulse 2.6s ease-out infinite;
      }
      .r1 { animation-delay: 0s; }
      .r2 { animation-delay: 0.7s; }
      .r3 { animation-delay: 1.4s; }
      .signal-active .signal-ring {
        border-color: var(--accent);
        animation-duration: 1.1s;
      }
      @keyframes signal-pulse {
        0% { transform: scale(0.6); opacity: 0.7; }
        100% { transform: scale(1.9); opacity: 0; }
      }

      .auth-title {
        font-family: 'Sora', sans-serif;
        font-size: 22px;
        font-weight: 600;
        text-align: center;
        margin: 0 0 8px;
        letter-spacing: -0.01em;
      }
      .auth-subtitle {
        font-size: 14px;
        line-height: 1.5;
        color: var(--text-dim);
        text-align: center;
        margin: 0 0 28px;
      }
      .phone-chip { color: var(--text); font-weight: 500; }

      .auth-form { display: flex; flex-direction: column; }
      .field-label {
        font-size: 12px;
        font-weight: 500;
        color: var(--text-dim);
        margin-bottom: 6px;
      }
      .phone-input {
        background: #0E1117;
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 13px 14px;
        font-size: 15px;
        color: var(--text);
        font-family: inherit;
        outline: none;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
      }
      .phone-input:focus {
        border-color: var(--accent);
        box-shadow: 0 0 0 3px var(--accent-dim);
      }
      .phone-input:disabled { opacity: 0.6; }

      .field-hint { font-size: 12px; color: var(--text-dim); margin: 8px 0 0; }
      .error-text { font-size: 13px; color: var(--danger); margin: 14px 0 0; line-height: 1.4; }

      .primary-btn {
        margin-top: 22px;
        background: var(--accent);
        color: #1A1300;
        border: none;
        border-radius: 12px;
        padding: 13px 16px;
        font-size: 15px;
        font-weight: 600;
        font-family: inherit;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 46px;
        transition: filter 0.15s ease, transform 0.05s ease;
      }
      .primary-btn:hover:not(:disabled) { filter: brightness(1.06); }
      .primary-btn:active:not(:disabled) { transform: scale(0.99); }
      .primary-btn:disabled { opacity: 0.7; cursor: not-allowed; }

      .btn-spinner {
        width: 18px;
        height: 18px;
        border-radius: 50%;
        border: 2.5px solid rgba(0,0,0,0.25);
        border-top-color: #1A1300;
        animation: btn-spin 0.7s linear infinite;
      }
      @keyframes btn-spin { to { transform: rotate(360deg); } }

      .otp-row { display: flex; gap: 8px; justify-content: space-between; }
      .otp-box {
        width: 44px;
        height: 52px;
        text-align: center;
        font-size: 20px;
        font-weight: 600;
        background: #0E1117;
        border: 1px solid var(--border);
        border-radius: 10px;
        color: var(--text);
        outline: none;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
      }
      .otp-box:focus {
        border-color: var(--accent);
        box-shadow: 0 0 0 3px var(--accent-dim);
      }
      .otp-box:disabled { opacity: 0.6; }

      .auth-links { display: flex; justify-content: space-between; margin-top: 18px; }
      .link-btn {
        background: none;
        border: none;
        color: var(--text-dim);
        font-size: 13px;
        font-family: inherit;
        cursor: pointer;
        padding: 4px;
      }
      .link-btn:hover:not(:disabled) { color: var(--text); }
      .link-btn:disabled { opacity: 0.5; cursor: not-allowed; }

      @media (prefers-reduced-motion: reduce) {
        .signal-ring { animation: none; opacity: 0.3; }
        .btn-spinner { animation-duration: 0.01ms !important; }
      }
    `}</style>
  );
}
