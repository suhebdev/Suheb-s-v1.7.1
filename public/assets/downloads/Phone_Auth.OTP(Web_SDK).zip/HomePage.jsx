import { useState } from "react";
import { logout } from "../firebase/auth";

export default function HomePage({ user }) {
  const [signingOut, setSigningOut] = useState(false);
  const [error, setError] = useState("");

  async function handleLogout() {
    setError("");
    setSigningOut(true);
    try {
      await logout();
      // onAuthStateChanged in App.jsx will swap back to AuthPage.
    } catch (err) {
      setError("Couldn't sign out. Check your connection and try again.");
      setSigningOut(false);
    }
  }

  const initials = (user.phoneNumber || "??").slice(-2);

  return (
    <div className="home-page">
      <div className="home-card">
        <div className="avatar">{initials}</div>
        <h1 className="home-title">You're signed in</h1>
        <p className="home-subtitle">{user.phoneNumber}</p>

        {error && <p className="home-error" role="alert">{error}</p>}

        <button className="logout-btn" onClick={handleLogout} disabled={signingOut}>
          {signingOut ? <span className="home-spinner" /> : "Sign out"}
        </button>
      </div>
      <Styles />
    </div>
  );
}

function Styles() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Sora:wght@600;700&family=Inter:wght@400;500;600&display=swap');

      .home-page {
        min-height: 100vh;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: radial-gradient(circle at 50% -10%, #161B24 0%, #0A0D12 55%);
        font-family: 'Inter', system-ui, sans-serif;
        padding: 24px;
        box-sizing: border-box;
      }
      .home-card {
        width: 100%;
        max-width: 360px;
        background: #13161D;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 20px;
        padding: 40px 32px;
        text-align: center;
        box-shadow: 0 20px 60px rgba(0,0,0,0.45);
      }
      .avatar {
        width: 56px;
        height: 56px;
        margin: 0 auto 18px;
        border-radius: 50%;
        background: rgba(242,169,59,0.16);
        color: #F2A93B;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: 'Sora', sans-serif;
        font-weight: 600;
        font-size: 18px;
        letter-spacing: 0.02em;
      }
      .home-title {
        font-family: 'Sora', sans-serif;
        font-size: 20px;
        font-weight: 600;
        color: #EDEFF3;
        margin: 0 0 6px;
      }
      .home-subtitle { font-size: 14px; color: #8A90A0; margin: 0 0 26px; }
      .home-error { font-size: 13px; color: #FF6B6B; margin: 0 0 16px; }
      .logout-btn {
        width: 100%;
        background: transparent;
        border: 1px solid rgba(255,255,255,0.14);
        color: #EDEFF3;
        border-radius: 12px;
        padding: 12px 16px;
        font-size: 14px;
        font-weight: 500;
        font-family: inherit;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 44px;
        transition: background 0.15s ease;
      }
      .logout-btn:hover:not(:disabled) { background: rgba(255,255,255,0.06); }
      .logout-btn:disabled { opacity: 0.6; cursor: not-allowed; }
      .home-spinner {
        width: 16px;
        height: 16px;
        border-radius: 50%;
        border: 2px solid rgba(255,255,255,0.2);
        border-top-color: #EDEFF3;
        animation: home-spin 0.7s linear infinite;
      }
      @keyframes home-spin { to { transform: rotate(360deg); } }
    `}</style>
  );
}
