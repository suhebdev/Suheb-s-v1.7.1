import { createRoot } from "react-dom/client";
import App from "./App";

// Note: React.StrictMode is intentionally omitted. In development it
// double-invokes effects, which can create the invisible reCAPTCHA twice
// and break phone sign-in. Feel free to add it back if you move the
// reCAPTCHA setup out of an effect.
createRoot(document.getElementById("root")).render(<App />);
