import { useState, useEffect } from "react";
import AuthPage from "./pages/AuthPage";
import HomePage from "./pages/HomePage";
import { subscribeToAuthChanges } from "./firebase/auth";

function App() {
  const [user, setUser] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToAuthChanges((currentUser) => {
      setUser(currentUser);
      setAuthChecked(true);
    });

    return () => unsubscribe();
  }, []);

  if (!authChecked) {
    return (
      <div style={styles.loadingScreen}>
        <style>{`
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
        `}</style>
        <div style={styles.spinner} />
      </div>
    );
  }

  return user ? <HomePage user={user} /> : <AuthPage />;
}

const styles = {
  loadingScreen: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: "100vh",
    background: "#F7F7F4"
  },
  spinner: {
    width: 30,
    height: 30,
    borderRadius: "50%",
    border: "3px solid #E6E6E2",
    borderTopColor: "#344E86",
    animation: "spin 0.7s linear infinite"
  }
};

export default App;
