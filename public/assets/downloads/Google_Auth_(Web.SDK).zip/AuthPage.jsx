import { useState } from "react";
import { signInWithGoogle } from "../firebase/auth";

const colors = {
  bg: "#F7F7F4",
  surface: "#FFFFFF",
  ink: "#1B1B1E",
  inkMuted: "#6B6B70",
  accent: "#344E86",
  accentSoft: "#E8ECF5",
  border: "#E6E6E2",
  online: "#3F9C6D",
  danger: "#B3261E",
  dangerSoft: "#FBEAE9"
};

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
      <path
        fill="#FFC107"
        d="M43.6 20.5H42V20H24v8h11.3C33.7 32.9 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.1 8 3l5.7-5.7C34.5 6 29.5 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.5z"
      />
      <path
        fill="#FF3D00"
        d="M6.3 14.7l6.6 4.8C14.6 16 19 13 24 13c3.1 0 5.9 1.1 8 3l5.7-5.7C34.5 6 29.5 4 24 4c-7.7 0-14.3 4.3-17.7 10.7z"
      />
      <path
        fill="#4CAF50"
        d="M24 44c5.3 0 10.1-1.8 13.8-4.9l-6.4-5.4C29.4 35.7 26.8 36.5 24 36.5c-5.3 0-9.7-3.1-11.3-7.5l-6.6 5.1C9.6 39.6 16.2 44 24 44z"
      />
      <path
        fill="#1976D2"
        d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.2 5.7l6.4 5.4C40.9 36.6 44 31 44 24c0-1.3-.1-2.7-.4-3.5z"
      />
    </svg>
  );
}

function AuthPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInWithGoogle();
    } catch (err) {
      setError("Could not sign you in. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&display=swap');
        @keyframes pulse {
          0% { box-shadow: 0 0 0 0 rgba(63, 156, 109, 0.45); }
          70% { box-shadow: 0 0 0 6px rgba(63, 156, 109, 0); }
          100% { box-shadow: 0 0 0 0 rgba(63, 156, 109, 0); }
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>

      <div style={styles.glowOne} />
      <div style={styles.glowTwo} />

      <div style={styles.card}>
        <div style={styles.sessionRow}>
          <span style={styles.sessionDot} />
          <span style={styles.sessionLabel}>Encrypted session</span>
        </div>

        <p style={styles.eyebrow}>Welcome</p>
        <h1 style={styles.heading}>Sign in to continue</h1>
        <div style={styles.accentRule} />
        <p style={styles.subtext}>
          Use your Google account to access your dashboard. We never see or
          store your password.
        </p>

        <button
          style={{
            ...styles.googleButton,
            ...(loading ? styles.googleButtonDisabled : {})
          }}
          onClick={handleGoogleSignIn}
          disabled={loading}
        >
          {loading ? (
            <span style={styles.spinner} />
          ) : (
            <GoogleIcon />
          )}
          <span>{loading ? "Signing you in…" : "Continue with Google"}</span>
        </button>

        {error && <div style={styles.errorBox}>{error}</div>}
      </div>
    </div>
  );
}

const styles = {
  page: {
    position: "relative",
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: colors.bg,
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    overflow: "hidden",
    padding: 24
  },
  glowOne: {
    position: "absolute",
    width: 420,
    height: 420,
    borderRadius: "50%",
    background: colors.accentSoft,
    filter: "blur(70px)",
    top: -140,
    left: -120,
    opacity: 0.8
  },
  glowTwo: {
    position: "absolute",
    width: 320,
    height: 320,
    borderRadius: "50%",
    background: "#E9F3EC",
    filter: "blur(80px)",
    bottom: -120,
    right: -100,
    opacity: 0.8
  },
  card: {
    position: "relative",
    zIndex: 1,
    width: "100%",
    maxWidth: 420,
    background: colors.surface,
    borderRadius: 20,
    border: `1px solid ${colors.border}`,
    boxShadow: "0 20px 50px rgba(27, 27, 30, 0.06)",
    padding: "40px 36px"
  },
  sessionRow: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    marginBottom: 24
  },
  sessionDot: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: colors.online,
    animation: "pulse 2s infinite"
  },
  sessionLabel: {
    fontSize: 12,
    fontWeight: 500,
    letterSpacing: "0.04em",
    color: colors.inkMuted,
    textTransform: "uppercase"
  },
  eyebrow: {
    margin: 0,
    fontSize: 13,
    fontWeight: 600,
    letterSpacing: "0.08em",
    textTransform: "uppercase",
    color: colors.accent
  },
  heading: {
    margin: "8px 0 0",
    fontFamily: "'Space Grotesk', sans-serif",
    fontSize: 28,
    fontWeight: 700,
    color: colors.ink,
    letterSpacing: "-0.01em"
  },
  accentRule: {
    width: 48,
    height: 3,
    borderRadius: 2,
    margin: "16px 0 18px",
    background: `linear-gradient(90deg, ${colors.accent}, ${colors.online})`
  },
  subtext: {
    margin: "0 0 28px",
    fontSize: 14.5,
    lineHeight: 1.6,
    color: colors.inkMuted
  },
  googleButton: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    padding: "13px 20px",
    fontFamily: "'Inter', sans-serif",
    fontSize: 15,
    fontWeight: 600,
    color: colors.ink,
    background: colors.surface,
    border: `1px solid ${colors.border}`,
    borderRadius: 12,
    cursor: "pointer",
    transition: "box-shadow 0.2s ease, border-color 0.2s ease",
    boxShadow: "0 1px 2px rgba(27, 27, 30, 0.04)"
  },
  googleButtonDisabled: {
    cursor: "default",
    opacity: 0.75
  },
  spinner: {
    width: 16,
    height: 16,
    borderRadius: "50%",
    border: `2px solid ${colors.border}`,
    borderTopColor: colors.accent,
    animation: "spin 0.7s linear infinite"
  },
  errorBox: {
    marginTop: 16,
    padding: "10px 14px",
    fontSize: 13.5,
    color: colors.danger,
    background: colors.dangerSoft,
    border: `1px solid ${colors.danger}22`,
    borderRadius: 10
  }
};

export default AuthPage;
