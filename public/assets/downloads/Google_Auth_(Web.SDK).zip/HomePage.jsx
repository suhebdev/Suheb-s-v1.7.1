import { useState } from "react";
import { signOutUser } from "../firebase/auth";

const colors = {
  bg: "#F7F7F4",
  surface: "#FFFFFF",
  ink: "#1B1B1E",
  inkMuted: "#6B6B70",
  accent: "#344E86",
  accentSoft: "#E8ECF5",
  border: "#E6E6E2",
  online: "#3F9C6D"
};

function getInitials(name, email) {
  if (name) {
    return name
      .split(" ")
      .map((part) => part[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();
  }
  return email ? email[0].toUpperCase() : "?";
}

function formatDate(value) {
  if (!value) return "—";
  return new Date(value).toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  });
}

function HomePage({ user }) {
  const [signingOut, setSigningOut] = useState(false);

  const handleSignOut = async () => {
    setSigningOut(true);
    try {
      await signOutUser();
    } finally {
      setSigningOut(false);
    }
  };

  const displayName = user?.displayName || "there";
  const firstName = displayName.split(" ")[0];

  return (
    <div style={styles.page}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&display=swap');
        @keyframes pulse {
          0% { box-shadow: 0 0 0 0 rgba(63, 156, 109, 0.45); }
          70% { box-shadow: 0 0 0 6px rgba(63, 156, 109, 0); }
          100% { box-shadow: 0 0 0 0 rgba(63, 156, 109, 0); }
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>

      <header style={styles.topBar}>
        <div style={styles.brand}>
          <span style={styles.brandDot} />
          <span style={styles.brandName}>Dashboard</span>
        </div>
        <button
          style={{
            ...styles.signOutButton,
            ...(signingOut ? styles.signOutButtonDisabled : {})
          }}
          onClick={handleSignOut}
          disabled={signingOut}
        >
          {signingOut ? "Signing out…" : "Sign out"}
        </button>
      </header>

      <main style={styles.main}>
        <div style={styles.card}>
          <div style={styles.sessionRow}>
            <span style={styles.sessionDot} />
            <span style={styles.sessionLabel}>Secure session</span>
          </div>

          <div style={styles.identityRow}>
            {user?.photoURL ? (
              <img src={user.photoURL} alt="" style={styles.avatarImg} />
            ) : (
              <div style={styles.avatarFallback}>
                {getInitials(user?.displayName, user?.email)}
              </div>
            )}
            <div>
              <h1 style={styles.heading}>Welcome back, {firstName}</h1>
              <p style={styles.subtext}>{user?.email}</p>
            </div>
          </div>

          <div style={styles.divider} />

          <dl style={styles.detailsGrid}>
            <div style={styles.detailItem}>
              <dt style={styles.detailLabel}>Provider</dt>
              <dd style={styles.detailValue}>Google</dd>
            </div>
            <div style={styles.detailItem}>
              <dt style={styles.detailLabel}>Account created</dt>
              <dd style={styles.detailValue}>
                {formatDate(user?.metadata?.creationTime)}
              </dd>
            </div>
            <div style={styles.detailItem}>
              <dt style={styles.detailLabel}>Last sign-in</dt>
              <dd style={styles.detailValue}>
                {formatDate(user?.metadata?.lastSignInTime)}
              </dd>
            </div>
          </dl>
        </div>
      </main>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: colors.bg,
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
  },
  topBar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "20px 32px",
    borderBottom: `1px solid ${colors.border}`,
    background: colors.surface
  },
  brand: {
    display: "flex",
    alignItems: "center",
    gap: 8
  },
  brandDot: {
    width: 9,
    height: 9,
    borderRadius: "50%",
    background: colors.accent
  },
  brandName: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontSize: 16,
    fontWeight: 600,
    color: colors.ink
  },
  signOutButton: {
    padding: "9px 18px",
    fontSize: 14,
    fontWeight: 600,
    color: colors.ink,
    background: colors.surface,
    border: `1px solid ${colors.border}`,
    borderRadius: 10,
    cursor: "pointer"
  },
  signOutButtonDisabled: {
    opacity: 0.6,
    cursor: "default"
  },
  main: {
    display: "flex",
    justifyContent: "center",
    padding: "64px 24px"
  },
  card: {
    width: "100%",
    maxWidth: 480,
    background: colors.surface,
    borderRadius: 20,
    border: `1px solid ${colors.border}`,
    boxShadow: "0 20px 50px rgba(27, 27, 30, 0.06)",
    padding: "32px 36px"
  },
  sessionRow: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    marginBottom: 24
  },
  sessionDot: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: colors.online,
    animation: "pulse 2s infinite"
  },
  sessionLabel: {
    fontSize: 12,
    fontWeight: 500,
    letterSpacing: "0.04em",
    color: colors.inkMuted,
    textTransform: "uppercase"
  },
  identityRow: {
    display: "flex",
    alignItems: "center",
    gap: 16
  },
  avatarImg: {
    width: 56,
    height: 56,
    borderRadius: "50%",
    objectFit: "cover",
    border: `1px solid ${colors.border}`
  },
  avatarFallback: {
    width: 56,
    height: 56,
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: colors.accentSoft,
    color: colors.accent,
    fontFamily: "'Space Grotesk', sans-serif",
    fontSize: 18,
    fontWeight: 600
  },
  heading: {
    margin: 0,
    fontFamily: "'Space Grotesk', sans-serif",
    fontSize: 22,
    fontWeight: 700,
    color: colors.ink,
    letterSpacing: "-0.01em"
  },
  subtext: {
    margin: "4px 0 0",
    fontSize: 14,
    color: colors.inkMuted
  },
  divider: {
    height: 1,
    background: colors.border,
    margin: "28px 0 20px"
  },
  detailsGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    rowGap: 16,
    columnGap: 12,
    margin: 0
  },
  detailItem: {
    display: "flex",
    flexDirection: "column",
    gap: 4
  },
  detailLabel: {
    margin: 0,
    fontSize: 11.5,
    fontWeight: 600,
    letterSpacing: "0.05em",
    textTransform: "uppercase",
    color: colors.inkMuted
  },
  detailValue: {
    margin: 0,
    fontSize: 14,
    fontWeight: 500,
    color: colors.ink
  }
};

export default HomePage;
