import { registerRootComponent } from "expo";
import App from "./App";

// registerRootComponent calls AppRegistry.registerComponent("main", () => App)
// and also handles whether the app is running in Expo Go or a native build.
registerRootComponent(App);
