import { initializeApp } from "firebase/app";
import { initializeAuth, getReactNativePersistence } from "firebase/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";

// ─────────────────────────────────────────────────────────────
// Firebase project credentials
// Get these from: Firebase Console > Project Settings > General
// (scroll to "Your apps" and select/create a Web app)
// ─────────────────────────────────────────────────────────────
const firebaseConfig = {
  apiKey: "PUT_YOUR_API_KEY_HERE",
  authDomain: "PUT_YOUR_AUTH_DOMAIN_HERE",
  projectId: "PUT_YOUR_PROJECT_ID_HERE",
  storageBucket: "PUT_YOUR_STORAGE_BUCKET_HERE",
  messagingSenderId: "PUT_YOUR_MESSAGING_SENDER_ID_HERE",
  appId: "PUT_YOUR_APP_ID_HERE",
  measurementId: "PUT_YOUR_MEASUREMENT_ID_HERE", // Optional
};

// ─────────────────────────────────────────────────────────────
// Google OAuth client IDs (used by expo-auth-session for the
// native Google sign-in flow on iOS/Android/Web/Expo Go).
// Get these from: Google Cloud Console > APIs & Services > Credentials
// (Firebase auto-creates a "Web client" once Google sign-in is
// enabled under Authentication > Sign-in method > Google)
// ─────────────────────────────────────────────────────────────
export const googleOAuthConfig = {
  expoClientId: "PUT_YOUR_EXPO_CLIENT_ID_HERE",
  webClientId: "PUT_YOUR_WEB_CLIENT_ID_HERE",
  iosClientId: "PUT_YOUR_IOS_CLIENT_ID_HERE",
  androidClientId: "PUT_YOUR_ANDROID_CLIENT_ID_HERE",
};

const app = initializeApp(firebaseConfig);

// initializeAuth + AsyncStorage persistence keeps the user signed in
// across app restarts (getAuth() alone does not persist on React Native)
export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage),
});

export default app;
