import {
  GoogleAuthProvider,
  signInWithCredential,
  signOut,
  onAuthStateChanged,
} from "firebase/auth";
import { auth } from "./config";

/**
 * Completes Firebase sign-in using the Google ID token returned by
 * expo-auth-session. Call this from the screen after a successful
 * Google OAuth response.
 */
export const signInWithGoogleCredential = async (idToken) => {
  const credential = GoogleAuthProvider.credential(idToken);
  return signInWithCredential(auth, credential);
};

/** Signs the current user out of Firebase. */
export const logout = () => signOut(auth);

/** Subscribes to auth state changes. Returns an unsubscribe function. */
export const subscribeToAuthChanges = (callback) =>
  onAuthStateChanged(auth, callback);

/** Synchronously returns the currently signed-in user, or null. */
export const getCurrentUser = () => auth.currentUser;

export default auth;
