import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
} from "react-native";
import * as WebBrowser from "expo-web-browser";
import * as Google from "expo-auth-session/providers/google";
import { googleOAuthConfig } from "../firebase/config";
import { signInWithGoogleCredential } from "../firebase/auth";

WebBrowser.maybeCompleteAuthSession();

export default function AuthPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [request, response, promptAsync] = Google.useIdTokenAuthRequest({
    expoClientId: googleOAuthConfig.expoClientId,
    webClientId: googleOAuthConfig.webClientId,
    iosClientId: googleOAuthConfig.iosClientId,
    androidClientId: googleOAuthConfig.androidClientId,
  });

  useEffect(() => {
    const completeSignIn = async () => {
      if (response?.type !== "success") return;

      setLoading(true);
      setError("");
      try {
        const { id_token } = response.params;
        await signInWithGoogleCredential(id_token);
        // Successful sign-in updates Firebase auth state; App.jsx listens
        // for that change and automatically navigates to HomePage.
      } catch (err) {
        setError("Sign-in failed. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    if (response?.type === "error") {
      setError("Google sign-in was cancelled or failed.");
    }

    completeSignIn();
  }, [response]);

  const handleGoogleSignIn = async () => {
    setError("");
    try {
      await promptAsync();
    } catch (err) {
      setError("Unable to start sign-in. Please try again.");
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.headerSection}>
          <View style={styles.logoCircle}>
            <Text style={styles.logoText}>A</Text>
          </View>
          <Text style={styles.title}>Welcome back</Text>
          <Text style={styles.subtitle}>
            Sign in to continue to your account
          </Text>
        </View>

        <View style={styles.inputContainer}>
          {error ? <Text style={styles.errorText}>{error}</Text> : null}

          <TouchableOpacity
            style={[
              styles.googleButton,
              (!request || loading) && styles.googleButtonDisabled,
            ]}
            onPress={handleGoogleSignIn}
            disabled={!request || loading}
            activeOpacity={0.8}
          >
            {loading ? (
              <ActivityIndicator color="#111827" />
            ) : (
              <>
                <Text style={styles.googleGlyph}>G</Text>
                <Text style={styles.googleButtonText}>
                  Continue with Google
                </Text>
              </>
            )}
          </TouchableOpacity>
        </View>

        <Text style={styles.footerText}>
          By continuing, you agree to our Terms of Service and Privacy Policy
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FAFAFA",
  },
  content: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: 28,
  },
  headerSection: {
    alignItems: "center",
    marginBottom: 48,
  },
  logoCircle: {
    width: 64,
    height: 64,
    borderRadius: 20,
    backgroundColor: "#111827",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 24,
  },
  logoText: {
    color: "#FFFFFF",
    fontSize: 26,
    fontWeight: "700",
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: "#6B7280",
    textAlign: "center",
  },
  inputContainer: {
    width: "100%",
  },
  errorText: {
    color: "#DC2626",
    fontSize: 13,
    textAlign: "center",
    marginBottom: 16,
  },
  googleButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 14,
    paddingVertical: 16,
    shadowColor: "#000000",
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  googleButtonDisabled: {
    opacity: 0.6,
  },
  googleGlyph: {
    fontSize: 18,
    fontWeight: "700",
    color: "#4285F4",
    marginRight: 10,
  },
  googleButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#111827",
  },
  footerText: {
    fontSize: 12,
    color: "#9CA3AF",
    textAlign: "center",
    marginTop: 32,
    lineHeight: 18,
  },
});
