# Auth App

A minimal, production-ready Expo app with Firebase Authentication + Google OAuth.

## File structure

```
src/
├── firebase/
│   ├── config.js   # Firebase + Google OAuth credentials (edit this)
│   └── auth.js      # signInWithGoogleCredential, logout, subscribeToAuthChanges
├── pages/
│   ├── AuthPage.jsx # Login screen
│   └── HomePage.jsx # Post-login screen
├── App.jsx           # Switches between AuthPage/HomePage based on auth state
└── main.jsx           # Expo entry point
```

## 1. Install dependencies

```bash
npm install
```

## 2. Create a Firebase project

1. Go to the [Firebase console](https://console.firebase.google.com) → **Add project**.
2. Inside the project, go to **Build → Authentication → Sign-in method** and enable **Google**.
3. Go to **Project settings → General → Your apps** and register a **Web app** (the gear icon → "</>"). You don't need hosting.
4. Copy the resulting config values into `src/firebase/config.js`, replacing every `PUT_YOUR_..._HERE` placeholder:

   ```js
   const firebaseConfig = {
     apiKey: "...",
     authDomain: "...",
     projectId: "...",
     storageBucket: "...",
     messagingSenderId: "...",
     appId: "...",
   };
   ```

## 3. Get your Google OAuth client IDs

Once Google sign-in is enabled in step 2, Firebase auto-creates OAuth clients in the linked Google Cloud project.

1. Go to [Google Cloud Console → APIs & Services → Credentials](https://console.cloud.google.com/apis/credentials) (same project as your Firebase project).
2. You'll see an auto-generated **Web client (auto created by Google Service)** — copy its **Client ID** into `webClientId` and `expoClientId` in `src/firebase/config.js`.
3. If you plan to build standalone iOS/Android apps, create additional OAuth client IDs of type **iOS** and **Android** (using your `bundleIdentifier` / `package` from `app.json`), and fill in `iosClientId` / `androidClientId`.
4. For the Web client, add this redirect URI under **Authorized redirect URIs** (needed while testing in Expo Go):
   ```
   https://auth.expo.io/@your-expo-username/auth-app
   ```
   Replace `your-expo-username` with your Expo account username and `auth-app` with the `slug` in `app.json` if you change it.

All four values live in one place: `src/firebase/config.js → googleOAuthConfig`.

## 4. Run the app

```bash
npx expo start
```

Scan the QR code with Expo Go (iOS/Android) or press `w` for web.

## How it works

- `AuthPage.jsx` uses `expo-auth-session`'s Google provider to open a Google sign-in flow and retrieve an ID token.
- That token is exchanged for a Firebase credential in `firebase/auth.js` (`signInWithGoogleCredential`), which signs the user into Firebase.
- `App.jsx` subscribes to Firebase's auth state (`subscribeToAuthChanges`) and renders `HomePage` once a user is present, or `AuthPage` otherwise — no extra navigation library needed.
- Auth state persists across app restarts via `initializeAuth` + AsyncStorage in `firebase/config.js`.
- `HomePage.jsx` displays the signed-in user's name, email, and avatar, with a working "Sign out" button.

## Notes for production builds

- For standalone (EAS) builds, you'll need the iOS/Android OAuth client IDs from step 3, and the `scheme` in `app.json` should match what you register with Google.
- Consider adding `expo-build-properties` / EAS config if you later add other native auth providers.
